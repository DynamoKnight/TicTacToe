import java.util.Arrays;

public class ChatTTT{
  /////////////////////////////
  // Properties
  /////////////////////////////
  
  private String[][] board;
  private String currentPlayer;
  private boolean gameEnded;
  private int SIZE = 3;

  /////////////////////////////
  // Constructors
  /////////////////////////////
  public ChatTTT(){
    board = new String [SIZE][SIZE];
    currentPlayer = "X";
    gameEnded = false;
    draw();
  }

  /////////////////////////////
  // Methods
  /////////////////////////////

  public void draw(){
    System.out.println();
    System.out.println(Arrays.toString(board[0]));
    System.out.println(Arrays.toString(board[1]));
    System.out.println(Arrays.toString(board[2]));
    System.out.println();
  }

  public String getCurrentPlayer(){
    return currentPlayer;
  }
  public boolean isGameEnded(){
    return gameEnded;
  }
  
  public void setGameEnded(boolean gameEnded){
    this.gameEnded = gameEnded;
  }

  public void setCurrentPlayer(String currentPlayer){
    this.currentPlayer = currentPlayer;
  }

  public String[][] getBoard(){
    return board;
  }
  
  public void setBoard(String[][] board){
    this.board = board;
  }

  public void makeMove(int row, int col, String player){
    // Can't place in an already controlled spot
    if(!board[row][col].equals("-")){
      throw new RuntimeException("Invalid move");
    }
    // Fills the spot
    board[row][col] = player;

    if (checkWin(player)){
      gameEnded = true;
    } //else if(checkTie()){
      //gameEnded = true;
    //} 
    else{
      currentPlayer = currentPlayer.equals("X") ? "O" : "X";
    }
  }

  private boolean checkWin(String player){
    // check rows
    for (int i = 0; i < 3; i++){
      if (board[i][0].equals(player) && board[i][i].equals(player) && board[i][2].equals(player)){
        return true;
      }
    }

    // check columns
  for(int i = 0; i < 3; i++){
    if(board[0][i].equals(player) && board[1][i].equals(player) && board[2][i].equals(player)){
      return true;
    }
  }
  
    // check diagonals
    if(board[0][0].equals(player) && board[1][1].equals(player)){
      return true;
    }

    if(board[0][2].equals(player) && board[1][1].equals(player) && board[2][0].equals(player)){
      return true;
    }
    return false;
  }

  /*
  public boolean checkTie(){
    for (int i = 0; i < 3; i++){
      for(int j = 0; j < 3; j++){
        
      }
    }
    return true;
  }
  */
}